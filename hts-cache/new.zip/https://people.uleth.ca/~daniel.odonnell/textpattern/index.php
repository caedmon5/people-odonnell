<!DOCTYPE html>
<html lang="en-gb" dir="ltr">
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow">
<title>Log in - Daniel Paul O&#039;Donnell &#124; Textpattern CMS</title>
<script src="vendors/jquery/jquery/jquery.js"></script>
<script src="vendors/jquery/jquery-ui/jquery-ui.js"></script>
<script>
var textpattern = {"_txp_uid":"248486cf107ca0608a7b7a0af057a02d","event":"login","step":null,"_txp_token":null,"ajax_timeout":30000,"prefs":{"max_file_size":"2097152","max_upload_size":"2097152","production_status":"live","do_spellcheck":"#page-article #body, #page-article #title,#page-image #image_alt_text, #page-image #caption,#page-file #description,#page-link #link-title, #page-link #link-description","language_ui":"en","message":"<span class=\"ui-icon ui-icon-{status}\"></span> {message}","messagePane":"<span class=\"messageflash {status}\" role=\"alert\" aria-live=\"assertive\">\n    {message}\n    <a class=\"close\" role=\"button\" title=\"{close}\" href=\"#close\"><span class=\"ui-icon ui-icon-close\">{close}</span></a>\n</span>"},"textarray":{}};
</script>
<script src="textpattern.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<link rel="stylesheet" href="admin-themes/hive/assets/css/textpattern.css">
<link rel="icon" href="admin-themes/hive/assets/img/favicon.ico">
<meta name="color-scheme" content="dark light">
<meta name="generator" content="Textpattern CMS">
<script defer src="admin-themes/hive/assets/js/main.js"></script>

<script defer src="admin-themes/hive/assets/js/autosize.js"></script>
</head>
<body class="not-ready login" id="page-login">
<noscript>Please enable JavaScript in your browser to use this application.</noscript>
<a class="txp-skip-link" href="#txp-main">Go to content</a>
<header class="txp-header">
<script src="admin-themes/hive/assets/js/darkmode.js"></script>


<h1><span>Textpattern</span></h1>

</header><!-- /txp-header -->
<main id="txp-main" class="txp-body">
<div class="messagepane" id="messagepane"></div>
<form class="txp-login" id="login_form" method="post" action="index.php">
<h1 id="txp-login-heading">Log in to Textpattern</h1>

<p class="login-language txp-reduced-ui"><label for="lang">Language</label>
<select name="lang" id="lang" data-submit-on="change">
<option value="ar" dir="auto">العربية</option>
<option value="de" dir="auto">Deutsch</option>
<option value="en-gb" dir="auto" selected="selected">English (British)</option>
<option value="en-us" dir="auto">English (American)</option>
<option value="es" dir="auto">Español</option>
<option value="fr" dir="auto">Français</option>
<option value="it" dir="auto">Italiano</option>
<option value="ja" dir="auto">日本語</option>
<option value="nl" dir="auto">Nederlands</option>
<option value="pt-br" dir="auto">Português (Brasil)</option>
<option value="ru" dir="auto">Русский</option>
<option value="th" dir="auto">ภาษาไทย</option>
<option value="ur" dir="auto">اردو</option>
<option value="vi" dir="auto">Tiếng Việt</option>
<option value="zh-cn" dir="auto">中文(简体)</option>
<option value="zh-tw" dir="auto">中文(繁體)</option>
</select>
</p>
<div class="txp-form-field login-name">
<div class="txp-form-field-label"><label for="login_name">Name</label></div>
<div class="txp-form-field-value">
<input name="p_userid" autocomplete="username" autofocus="autofocus" id="login_name" type="text" size="32" required="required" placeholder="Required" value="" /></div>
</div>
<div class="txp-form-field login-password">
<div class="txp-form-field-label"><label for="login_password">Password</label></div>
<div class="txp-form-field-value">
<input name="p_password" autocomplete="current-password" id="login_password" type="password" size="32" required="required" placeholder="Required" value="" /></div>
</div>
<p class="login-stay">
<input class="checkbox" id="login_stay" name="stay" type="checkbox" value="1" />
<label for="login_stay">Remain logged in with this browser</label>&#160;<a rel="help" title="Help" role="button" class="pophelp" data-item="&lt;div id=&quot;pophelp-event&quot; dir=&quot;auto&quot;&gt;&lt;h2&gt;Remain logged in with this browser&lt;/h2&gt;
&lt;p&gt;When checked, you will remain logged in to your Textpattern account with the current web browser, until you choose to log out. If left unchecked, you will be automatically logged out after a period of inactivity.&lt;/p&gt;
&lt;p&gt;Requires cookies to be enabled in your browser.&lt;/p&gt;
&lt;/div&gt;" href="#"><span class="ui-icon ui-icon-help">Help</span></a></p>
<p>
<input class="publish" type="submit" value="Log in" /></p>
<p class="login-forgot"><a href="?reset=1&lang=en-gb">Forgot password?</a></p>
<p class="login-view-site"><a title="View site" href="https://people.uleth.ca/~daniel.odonnell/">Daniel Paul O'Donnell</a></p>
<input name="_txp_token" type="hidden" value="" />
</form>
<script>
textpattern.textarray = {"are_you_sure":"Are you sure?","close":"Close","cookies_must_be_enabled":"Browser cookies must be enabled to use Textpattern.","documentation":"Documentation","form_submission_error":"Sorry, the form could not be submitted. Please try again later.","help":"Help","list_options":"Column display options","ok":"ok","plugin_help":"plugin_help","publish":"Publish","save":"Save","select":"Select","toggle_all_selected":"Toggle all/none selected","upload_err_form_size":"File exceeds the maximum size specified in Textpattern’s preferences.","with_selected_option":"With {count} selected…"}
</script>
</main><!-- /txp-body -->
</body>
</html>