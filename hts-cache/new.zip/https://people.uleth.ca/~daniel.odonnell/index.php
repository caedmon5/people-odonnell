<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<!-- head -->
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="google-site-verification" content="9ZHP1FDttD1YeXYP4jrDb8KmwNTGqQgRb92Y1B3M_Ro" />
		<title>
			Daniel Paul O&#039;Donnell
		</title>

		<!-- txp:feed_link flavor="atom" format="link" label="Atom"/ -->
		<!-- txp:feed_link flavor="rss" format="link" label="RSS"/ -->
		<link rel="shortcut icon" href="https://people.uleth.ca/~daniel.odonnell/transparent.ico" />
		<style type="text/css" media="screen" title="Default"> @import url(https://people.uleth.ca/~daniel.odonnell/css/txpscreen.css); </style>
		<style type="text/css" media="print,mobile" title="Default"> @import url(https://people.uleth.ca/~daniel.odonnell/css/txpprint.css); </style>
		<style type="text/css" media="all" title="Default"> @import url(https://people.uleth.ca/~daniel.odonnell/css/txpcommonstyles.css); </style>

<!-- hypothes.is enabled via the following. See https://hypothes.is/for-publishers/ -->

<!-- the following disables default show highlighting -->
<!-- <script>window.hypothesisConfig = function () { return {showHighlights: false}; };</script> -->
<!-- the following loads the annotator -->
<script defer async src="//hypothes.is/embed.js"></script>

<!-- end hypothes.is enabling -->
		<script type="text/javascript">
			var _gaq = _gaq || [];
			_gaq.push(['_setAccount', 'UA-32780614-1']);
			_gaq.push(['_trackPageview']);
			(function() {
				var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
				ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();
		</script>
	</head>
	<!-- body -->
	<body>
		<div class="body">

			<!-- Top bar -->
			<div class="head">
				<div>
					<h1 style="vertical-align:center">
						<a href="http://people.uleth.ca/~daniel.odonnell/">
							<img src="http://people.uleth.ca/~daniel.odonnell/images/11.png" alt="Reverse detail from Kakelbont MS 1, a fifteenth-century French Psalter. This image is in the public domain." title="Reverse detail from Kakelbont MS 1, a fifteenth-century French Psalter. This image is in the public domain." id="logoimage" width="10%"/></a> <span style="vertical-align:center">Daniel Paul O&#039;Donnell</span>
					</h1>
				</div>
			</div>

		</div>
<!-- breadcrumb -->
				<div class="breadcrumb">
					<p>
						
						
							<a href="https://people.uleth.ca/~daniel.odonnell/">Daniel Paul O'Donnell</a> » <a href="https://people.uleth.ca/~daniel.odonnell/">Home</a>
						
					</p>
				</div>
<!-- end breadcrumb -->

		<!-- content -->
		<div class="content">
			<p class="hideme">
				<a class="hideme" id="content"></a>
				<a href="#navigation" class="hideme">Forward to Navigation</a>
			</p>
			<!-- section logic begins -->
			 <!-- debug #1 -->
			
				<!-- we are on the default section (front page) -->
				<!-- #1c --> 
				<!-- default page form begins -->



<h2>Welcome</h2>
<div style="background-color:light gray">
<p><strong><a rel="author" href="https://people.uleth.ca/~daniel.odonnell/author/Daniel+Paul+O%27Donnell/">Daniel Paul O&#039;Donnell</a></strong></p>
<p>Posted: Dec 04, 2006 07:12;<br/>Last Modified: Jun 25, 2021 15:06<br/>
Keywords: <seg onload="displayLinks()"></seg></p>

<script>
        // Place the JavaScript function here
        function generateLinkTags(keywords) {
            let linkTags = "'";
            keywords.forEach(keyword => {
                let link = `<a href='https://home.uleth.ca/~daniel.odonnell/tags/{encodeURIComponent(keyword)}'>${keyword}</a>`;
                linkTags += link + "<br>";
            });
            return linkTags;
        }

        // This function will be called once the page is fully loaded
        function displayLinks() {
            let keywords = ["JavaScript", "OpenAI", "Web Development"];
            let htmlLinks = generateLinkTags(keywords);
            document.body.innerHTML = htmlLinks;
        }
    </script>




</div>
<img src="https://people.uleth.ca/~daniel.odonnell/images/1.gif" width="400" height="1" class="divider" alt="---" title="Section separator" />
<!--
<img src="https://people.uleth.ca/~daniel.odonnell/images/12.png" alt="----" title="Section separator: detail from Kakelbont MS 1, a fifteenth-century French Psalter. This image is in the public domain." style="max-width:300px;text-align:center"/>
-->
<!-- automatic TOC begins after this -->
<div id="TOC">
   <!--txp:soo_toc label="Contents" labeltag="h3"/-->
</div>
<!-- automatic TOC ends -->
<p><span style="font-size: smaller; padding-top: .5em; padding-bottom: .5em; position: relative; float: right; padding-left: .5em; border: none; width: 15em; text-align: center; wrod-wrap: break-word;"><img class="imagecache-inline_default" title="Scanning Ruthwell Cross Fragment" style="height: 12em;" src="http://people.uleth.ca/~daniel.odonnell/images/ruthwellStone.jpg"/><em>Scanning a cross fragment in <a href="https://www.google.ca/maps/@55.000268%2C-3.4074822%2C186m/data%3D%213m1%211e3">Ruthwell Kirk</a> for the <a href="http://visionarycross.org">Visionary Cross Project</a></em></span></p>

<p>Welcome to my <a href="http://people.uleth.ca/~daniel.odonnell/About/changes-to-my-web-space">University of Lethbridge Home Page</a>. </p>

<p>I am a Professor in the <a href="http://www.uleth.ca/fas/eng/">Department of English</a> at the <a href="http://www.uleth.ca/">University of Lethbridge</a> and the <a href="http://www.uleth.ca/lib/">University Library</a>. In the Department of English, I am responsible for teaching most of our courses on Digital Humanities, medieval literature, the History of the Book, History of English, and the English language/grammar. I also share responsibility for our first year introductory course, English 1900. You can find out more about my teaching by following <a href="http://people.uleth.ca/~daniel.odonnell/Teaching/">this link</a>. </p>

<p>My main research interests include Digital Humanities, Scholarly Communication, Old English language and literature, the history of the book, editorial and textual scholarship, and reception-oriented criticism. I maintain a <a href="https://zenodo.org/communities/dpodrepository/" title="mostly complete">preprint and offprint library where you can access copies of my work at Zenodo</a>, in <a href="https://opus.uleth.ca/handle/10133/3557" title="Opus">the University&#8217;s Institutional Repository</a> (less complete), and in various commercial sites such as Academic.edu and Research Gate (much less complete). My <a href="http://scholar.google.ca/citations?user=4WlgWHwAAAAJ&amp;hl=en">Google Scholar Profile</a> lists most of my publications; <a href="https://www.dropbox.com/s/w5ls8bazw317yyl/CV.pdf?dl=0">my CV</a> and <a href="https://uniweb.uleth.ca/members/15">Uniweb Profile</a> should have all of them.</p>

<p>My current research projects include </p>

<ul>
	<li><a href="http://force11.org/fsci" title="FSCI">The FORCE11 Scholarly Communications Institution</a>. This is a week-long, international and cross-disciplinary summer school on the latest developments in research communication, held most years at <span class="caps">UCLA</span> in the first week of August. This year, it will be held online due to pandemic travel restrictions. I am the founding director of the Steering Committee.</li>
	<li>The <strong>Visionary Cross Project</strong> (<a href="http://www.visionarycross.org/">http://www.visionarycross.org/</a>). This is an international project studying the “Visionary Cross” cultural matrix in Anglo-Saxon England, particularly as it is represented in the Ruthwell Cross, Bewcastle Cross, Brussels Cross, and the Vercelli Book poems <em>The Dream of the Rood</em> and <em>Elene</em>. We are currently in the process of digitizing the Ruthwell Cross, funded by <span class="caps">SSHRC</span> and the <span class="caps">AHRC</span>.</li>
	<li>The <strong>Lethbridge Journal Incubator</strong> (<a href="http://www.uleth.ca/lib/incubator/">http://www.uleth.ca/lib/incubator/</a> and <a href="http://www.journalincubator.org/">http://www.journalincubator.org/</a>). This project addresses the problem of sustainability in the publication of scholarly journals, by aligning its costs with university educational missions. Work on this project involves developing robust and generalisable <span class="caps">XML</span>-based workflows for journal production and training material for student assistants. The result will be an open source production process and business model that will able to encourage academics to experiment with new forms of scholarly publication.</li>
	<li><a href="http://dpod.kakelbont.ca/2012/11/12/global-outlook-digital-humanities-and-international-partnerships/">Global Outlook::Digital Humanities</a> (go::dh). This is a Special Interest Group dedicated to bridging the divide that separates high income economies from mid- and low-income economies in the practice of Digital Humanities.</li>
	<li><a href="https://www.force11.org/">Force11</a> Force11 is a community of scholars, librarians, archivists, publishers and research funders that has arisen organically to help facilitate the change toward improved knowledge creation and sharing. Individually and collectively, we aim to bring about a change in modern scholarly communications through the effective use of information technology.</li>
	<li><a href="http://www.uleth.ca/research/centre-study-scholarly-communications">Centre for the Study of Scholarly Communication</a> The <span class="caps">CSSC</span> is a new Centre at the University of Lethbridge that provides a home for clinical and pure research in Library and Information Science, Research Communication, Publishing, and Knowledge Mobilization, focusing particularly on work on new forms of research communication in the Digital Age.</li>
</ul>

<p><span style="font-size: smaller; padding-top: .5em; padding-bottom: .5em; position: relative; float: left; clear:bottom; padding-left: .5em; border: none; width: 15em; text-align: center; wrod-wrap: break-word;"><a href="http://orcid.org/0000-0002-0127-4893"><img class="imagecache-inline_default" title="QR Code for my Orchid ID" style="height: 12em;" src="http://people.uleth.ca/~daniel.odonnell/images/147.png"/></a><br/><em>QR code of my <a href="http://orcid.org/"><span class="caps">ORCID</span> number</a> <b><a href="http://orcid.org/0000-0002-0127-4893">0000-0002-0127-4893</a></b></em></span><span style="font-size: smaller; padding-top: .5em; padding-bottom: .5em; position: relative; float: right; clear:top; padding-left: .5em; border: none; width: 15em; text-align: center; wrod-wrap: break-word;"><a title="Link to my Google Scholar Profile" href="http://scholar.google.ca/citations?user=4WlgWHwAAAAJ&hl=en"><img width="256" alt="Google Scholar logo" src="//upload.wikimedia.org/wikipedia/commons/2/28/Google_Scholar_logo.png"/></a><em>Link to my <a href="http://scholar.google.com">Google Scholar</a> Profile.</em></span>In addition to these research projects, I have been active for the last several years in academic and research administration. I am a past president of the <a href="http://www.sdh-semi.org/">Society for Digital Humanities / Société pour l’étude des médias interactifs</a>, a Canada-wide association that both draws together humanists who are engaged in digital and computer-assisted research, teaching, and creation and participates in international efforts to call attention to the importance of digital technology in the practice of the humanities through partnerships with other agencies. I am co-editor of <a href="http://www.digitalstudies.org/">Digital Studies / Le champ numérique</a> and associate editor of Digital Medievalist (<a href="http://www.digitalmedievalist.org/journal/">http://www.digitalmedievalist.org/journal/</a>), a journal I helped found. In previous years I have been Chair and <span class="caps">CEO</span> of the <strong>Text Encoding Initiative (<span class="caps">TEI</span>)</strong> <a href="http://www.tei-c.org/">(http://www.tei-c.org/)</a> (2006-2010), founding director of the <a href="http://www.digitalmedievalist.org/">Digital Medievalist Community of Practice</a> (2003-2009), and chair of my department (2004-2007).</p>

<p>There are a number of different ways of finding out about me or my research and teaching:</p>

<ul>
	<li><a href="https://www.dropbox.com/s/dtx35eysttp23ik/CV.pdf?dl=0" title="education, publications, etc.">My academic <em>curriculum vitae</em></a></li>
	<li><a href="http://dpod.kakelbont.ca/">My other blog</a> (originally separate from this; now a mirror).</li>
	<li>My <a href="http://orcid.org/">Orchid</a> ID is <a href="http://orcid.org/0000-0002-0127-4893">0000-0002-0127-4893</a>.</li>
	<li>My <a href="https://zenodo.org/communities/dpodrepository/">personal repository at Zenodo</a> or my articles in <a href="https://opus.uleth.ca/handle/10133/3557">Opus, the University of Lethbridge&#8217;s Institutional Repository</a></li>
	<li>My profiles at
	<ul>
		<li><a href="http://scholar.google.ca/citations?user=4WlgWHwAAAAJ">Google Scholar</a></li>
		<li><a href="https://academic.microsoft.com/profile/22e6118f-2493-48i7-e543-806472873fjf/DanielPaulO%26apos%3BDonnell/">Microsoft Academic</a></li>
		<li><a href="https://uniweb.uleth.ca/members/15" title="University of Lethbridge">Uniweb</a></li>
		<li><a href="http://orcid.org/0000-0002-0127-4893"><span class="caps">ORCID</span> (0000-0002-0127-4893</a>)</li>
	</ul></li>
	<li>You can also follow me on <a href="http://twitter.com">Twitter</a> as <a href="https://twitter.com/DanielPaulOD">@DanielPaulOD</a> (but to be honest I don&#8217;t post there much any more).</li>
</ul>
<!-- <img src="https://people.uleth.ca/~daniel.odonnell/images/1.gif" width="400" height="1" class="divider" alt="---" title="Section separator" />
<p>Posted: Monday December  4, 2006. 07:47.</p> 
<p>Last modified: Friday June 25, 2021. 15:53.</p> -->
<div class="comments">
<img src="https://people.uleth.ca/~daniel.odonnell/images/12.png" alt="----" title="Section separator: detail from Kakelbont MS 1, a fifteenth-century French Psalter. This image is in the public domain." style="max-width:300px;text-align:center"/>
<!-- txp:comments_invite wraptag="p" / -->
<!-- txp:comments_form / -->
&#x00A0;
</div>
<!-- default page form ends -->
			<!-- #1e --> 
			
		</div>

		<!-- Right bar -->
		<!--googleoff: all-->
		<!-- this stops google indexing the tweets and other static information -->
		<div class="rightbar">
			<p class="hideme">
				<a class="hideme" id="navigation"></a>
				<a href="#content" class="hideme">Back to content</a>
			</p>
<div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.FloatPosition.BOTTOM_RIGHT, autoDisplay: false, gaTrack: true, gaId: 'UA-32780614-1'}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        
			<h2>Search my site</h2>
				<form role="search" method="get" action="https://people.uleth.ca/~daniel.odonnell/Search/">
<p class="search_input">
<input name="q" required="required" size="15" type="search" value="" /><input type="submit" value="Go!" /></p>
</form>
			<h2>Sections</h2>
			<ul>
<li><a href="https://outlook.office.com/bookwithme/user/a14f92d19eb24afdab3a3bc6938f09f7@uleth.ca/meetingtype/vFTDmf-nQECoMYPMEtPS2A2?anonymous&ep=mlink">Book a meeting time with me</a></li>				
<li><a href="http://people.uleth.ca/~daniel.odonnell/Academic-Policies/current-academic-policies">Academic Policies (Current)</a></li>
				<li><a href="https://people.uleth.ca/~daniel.odonnell/blog/">Blog</a></li>
<li><a href="https://people.uleth.ca/~daniel.odonnell/contact/">Contact</a></li>
<li><a href="https://people.uleth.ca/~daniel.odonnell/research/">Research</a></li>
<li><a href="https://people.uleth.ca/~daniel.odonnell/teaching/">Teaching</a></li>
<li><a href="https://people.uleth.ca/~daniel.odonnell/tutorials/">Tutorials</a></li>
			</ul>
<!-- h2>Schedule</h2>

<iframe 
name="My calendar"
title="My calendar"
width="75%"
scrolling="yes"
marginheight="0"
marginwidth="0"
src="https://outlook.office365.com/owa/calendar/a14f92d19eb24afdab3a3bc6938f09f7@uleth.ca/2c4f66847b2042dfb7db8ba348396f3c14689327663406417309/calendar.html"/>
-->
<h2>Current teaching</h2>
			<ul>

<li><a href="https://people.uleth.ca/~daniel.odonnell/teaching/english-4400b-7400b-readers-researchers-and-books-case-studies-in-reception-spring-2024">English 4400b/7400b: Readers, Researchers, and Books: Case Studies in Reception (Spring 2024)</a></li>

<li><a href="https://people.uleth.ca/~daniel.odonnell/teaching/english-4850a-7850a-beowulf-spring-2024">English 4850a/7850a: Advanced Old English (Spring 2024)</a></li>



			</ul>
			<h2>Recent changes to this site</h2>
			<ul>
				<li><strong><a rel="bookmark" href="https://people.uleth.ca/~daniel.odonnell/blog/calm-slippery-and-sadistic-my-silent-war-by-kim-philby-and-a-spy-among-friends-by-ben-macintyre">Calm, Slippery, and sadistic: My Silent War by Kim Philby and A Spy among Friends by Ben MacIntyre</a> </strong></li><li><strong><a rel="bookmark" href="https://people.uleth.ca/~daniel.odonnell/blog/chatbot-prompt-thyself">ChatBot prompt thyself</a> </strong></li><li><strong><a rel="bookmark" href="https://people.uleth.ca/~daniel.odonnell/blog/what-a-fuss-about-an-omlette-why-lies-are-protected-speech-in-the-us">What a fuss about an omlette! Why lies are protected speech in the U.S. (Liar in a crowded theater; Kosseff 2023)</a> </strong></li><li><strong><a rel="bookmark" href="https://people.uleth.ca/~daniel.odonnell/blog/blow-by-blow-island-victory-sla-marshall-1944-2002">Blow by blow: Island Victory, S.L.A. Marshall 1944/2002</a> </strong></li><li><strong><a rel="bookmark" href="https://people.uleth.ca/~daniel.odonnell/teaching/english-4400b-7400b-readers-researchers-and-books-case-studies-in-reception-spring-2024">English 4400b/7400b: Readers, Researchers, and Books: Case Studies in Reception (Spring 2024)</a> </strong></li>
			</ul>
			<h2>Tags</h2>
			<a href="https://people.uleth.ca/~daniel.odonnell/tag/anglo-saxon+studies/" class="tagSizeMedium tagSize11" style="font-size: 135%;">anglo-saxon studies</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/caedmon/" class="tagSizeSmallest tagSize1" style="font-size: 100%;">caedmon</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/citation+practice/" class="tagSizeSmallest tagSize1" style="font-size: 100%;">citation practice</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/composition/" class="tagSizeSmallest tagSize1" style="font-size: 100%;">composition</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/computers/" class="tagSizeMedium tagSize24" style="font-size: 182%;">computers</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/digital+humanities/" class="tagSizeLargest tagSize29" style="font-size: 200%;">digital humanities</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/digital+pedagogy/" class="tagSizeMedium tagSize2" style="font-size: 103%;">digital pedagogy</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/grammar/" class="tagSizeMedium tagSize3" style="font-size: 107%;">grammar</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/history/" class="tagSizeMedium tagSize2" style="font-size: 103%;">history</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/moodle/" class="tagSizeSmallest tagSize1" style="font-size: 100%;">moodle</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/old+english/" class="tagSizeMedium tagSize6" style="font-size: 117%;">old english</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/pedagogy/" class="tagSizeMedium tagSize13" style="font-size: 142%;">pedagogy</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/research/" class="tagSizeMedium tagSize4" style="font-size: 110%;">research</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/students/" class="tagSizeMedium tagSize7" style="font-size: 121%;">students</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/study+tips/" class="tagSizeMedium tagSize3" style="font-size: 107%;">study tips</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/teaching/" class="tagSizeMedium tagSize10" style="font-size: 132%;">teaching</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/tips/" class="tagSizeMedium tagSize16" style="font-size: 153%;">tips</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/tutorials/" class="tagSizeMedium tagSize12" style="font-size: 139%;">tutorials</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/unessay/" class="tagSizeMedium tagSize8" style="font-size: 125%;">unessay</a>, 
<a href="https://people.uleth.ca/~daniel.odonnell/tag/universities/" class="tagSizeMedium tagSize3" style="font-size: 107%;">universities</a><br /><br />
			<a style="padding-left:1em;" href="http://people.uleth.ca/~daniel.odonnell/tag/">See all...</a>
			<!-- <h2>What I'm reading...</h2> -->
			<!-- txp:aks_rss form="externalRSS" feed="https://api.zotero.org/groups/81065/items/" limit_per_feed="4" wraptag="ul" break="li" /> -->
			<!-- <h2>Bibliography ticker...</h2> -->
			<!-- txp:aks_rss form="citationTicker" feed="https://api.zotero.org/users/632779/items?key=lSavInnm7WmefW45BRO6f7uh" limit_per_feed="4" wraptag="p" break="<span />" /> -->
			<h2>Follow me on <a href="https://twitter.com/#!/DanielPaulOD">Twitter</a></h2>
			<ul class="arc_twitter"><li><a href='http://twitter.com/LorinYochim' rel='external'>@LorinYochim</a> <a href='http://twitter.com/CAUT_ACPPU' rel='external'>@CAUT_ACPPU</a> <a href='http://twitter.com/case_acse' rel='external'>@case_acse</a> <a href='http://twitter.com/CSSESCEE' rel='external'>@CSSESCEE</a> <a href='http://twitter.com/UMFA_FAUM' rel='external'>@UMFA_FAUM</a> <a href='http://twitter.com/ULFAssociation' rel='external'>@ULFAssociation</a> I&#039;m afraid I don&#039;t. I thought it was one o&hellip; <a href='https://twitter.com/i/web/status/1673712143542390785'>twitter.com/i/web/status/1…</a> <span class="arc_twitter-posted">Jun 27, 09:17 AM</span></li>
<li>RT <a href='http://twitter.com/BUFABrock' rel='external'>@BUFABrock</a>: The results are in!

<a href='http://twitter.com/BUFABrock' rel='external'>@BUFABrock</a>&nbsp;members have voted 97% in favour of strike authorization, if necessary.

The participation r&hellip; <span class="arc_twitter-posted">Jun 27, 08:33 AM</span></li>
<li><a href='http://twitter.com/LorinYochim' rel='external'>@LorinYochim</a> <a href='http://twitter.com/CAUT_ACPPU' rel='external'>@CAUT_ACPPU</a> <a href='http://twitter.com/case_acse' rel='external'>@case_acse</a> <a href='http://twitter.com/CSSESCEE' rel='external'>@CSSESCEE</a> <a href='http://twitter.com/UMFA_FAUM' rel='external'>@UMFA_FAUM</a> <a href='http://twitter.com/ULFAssociation' rel='external'>@ULFAssociation</a> I thought I heard talk of this at caut this year. <span class="arc_twitter-posted">Jun 27, 08:30 AM</span></li>
<li>RT <a href='http://twitter.com/deelomas' rel='external'>@deelomas</a>: And, the official winner of the &lsquo;Not My Job&rsquo; award goes to&hellip; <a href='https://twitter.com/deelomas/status/1672611829967667202/photo/1'>pic.twitter.com/0sDes9D5oq</a> <span class="arc_twitter-posted">Jun 26, 09:34 PM</span></li>
<li>I&#039;m beginning to think that electric vehicles are sort of a Linux of the car world at the moment. Except Teslas whi&hellip; <a href='https://twitter.com/i/web/status/1673344791856267271'>twitter.com/i/web/status/1…</a> <span class="arc_twitter-posted">Jun 26, 08:57 AM</span></li>
<li>&quot;He felt that American children in recent generations have had too much parental protection and too little opportun&hellip; <a href='https://twitter.com/i/web/status/1670627745641172993'>twitter.com/i/web/status/1…</a> <span class="arc_twitter-posted">Jun 18, 09:01 PM</span></li>
<li>I&#039;ve been going through Ernie Pyle&#039;s Brave Men (a collection of columns from the European front in WWII) looking up&hellip; <a href='https://twitter.com/i/web/status/1670263169556836354'>twitter.com/i/web/status/1…</a> <span class="arc_twitter-posted">Jun 17, 08:52 PM</span></li>
<li>Traditionally, &ldquo;knowledge workers&rdquo; have had two productivity peaks in their workday: just before lunch and just aft&hellip; <a href='https://twitter.com/i/web/status/1667749991186833409'>twitter.com/i/web/status/1…</a> <span class="arc_twitter-posted">Jun 10, 10:25 PM</span></li>
<li>RT <a href='http://twitter.com/JasonOnTheDrums' rel='external'>@JasonOnTheDrums</a>: <a href='http://twitter.com/search?q=%23Ableg' rel='external'>#Ableg</a>

Today was within 97% of the record votes we record on Tuesday.

We&rsquo;re on pace for 784,475 votes over and will&hellip; <span class="arc_twitter-posted">May 26, 08:08 PM</span></li>
<li>So if we were doing bets,  here&#039;s mine: 

NDP 45
UCP 41
IND (Child-hating poop-cookie) 1

I think people are undere&hellip; <a href='https://twitter.com/i/web/status/1662279319685849088'>twitter.com/i/web/status/1…</a> <span class="arc_twitter-posted">May 26, 08:07 PM</span></li></ul>
			<!--  <h2><form method="get" action="https://people.uleth.ca/~daniel.odonnell/"><div>
Navigation<br />
<select name="s" onchange="submit(this.form);">
	<option value="" selected="selected">&#160;</option>
	<option value="about">About</option>
	<option value="academic-policies">Academic Policies</option>
	<option value="archive">Archive</option>
	<option value="blog">Blog</option>
	<option value="contact">Contact</option>
	<option value="drafts">Drafts</option>
	<option value="research">Research</option>
	<option value="search">Search</option>
	<option value="tag">All Tags</option>
	<option value="teaching">Teaching</option>
	<option value="tutorials">Tutorials</option>
</select>
<noscript><div><input type="submit" value="Go" /></div></noscript>
</div>
</form></h2> -->
			<!-- h2>At <a href="http://dpod.kakelbont.ca/">the dpod blog</a></h2 -->
			<!-- txp:aks_rss form="externalRSS" feed="http://dpod.kakelbont.ca/feed/" limit_per_feed="10" wraptag="ul" break="li"/ -->
		</div>
		<div class="footer">
<p>Our University’s Blackfoot name is Iniskim, meaning Sacred
Buffalo Stone.<br/>The University is located in traditional Blackfoot Confederacy territory.<br/>We honour the Blackfoot
people and their traditional ways of knowing in caring for this land, as well as all Aboriginal peoples who have
helped shape and continue to strengthen our University community.</p>
			<p><a href="http://www.uleth.ca/">University of Lethbridge</a> | <a href="http://www.uleth.ca/artsci/">Faculty of Arts and Science</a> | <a href="http://www.uleth.ca/artsci/english">Department of English</a> | <a href="http://www.uleth.ca/graduatestudies/">School of Graduate studies</a> | <a href="http://people.uleth.ca/~daniel.odonnell/textpattern/index.php">Site
Administration</a><br />&copy; Date of publication or modification by Daniel Paul O'Donnell<br />Unless otherwise noted, the non-negotiated licence for all work on this site is <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/">Creative Commons
Attribution-NonCommercial-ShareAlike 3.0 Unported License</a>.<br /><a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/"><img alt="Creative Commons License" style="border-width:0;" src="http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png" /></a>.<br />If you want to use the work in some other fashion, feel free to contact me. </p>
		</div>
		<!--googleon: all-->
	</body>
</html>